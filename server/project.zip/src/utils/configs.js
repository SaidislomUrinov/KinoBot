export default {
    port: 5000,
    token: '7428164088:AAG-HyB7ufr__DcrgnoC4g4CGGSEA3p1Cx4',
    mongoUrl: 'mongodb://127.0.0.1:27017/gapyoq',
    admins: [5991285234],
    access: 'sasasasd65f67g89jio'
}